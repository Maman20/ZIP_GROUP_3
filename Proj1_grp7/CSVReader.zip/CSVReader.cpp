/**
 * @file CSVReader.cpp
 * @callergraph
 * @callgraph
 * @author Fabian MullerDahlberg
 * @authors (Testing done by Shishir) (Doxygen documentation by Abdi and Shishir)
 * @brief Member function definitions for class CSVReader
 * @see CCSVReader.h for declaration.
 * @details
 * - Constructor: Opens a specified CSV file for reading.
 * - isOpen(): Checks if the CSV file is currently open.
 * - GetHeaders(): Parses and stores the header row of the CSV file, populating the Headers vector with column headers.
 * - ReadFile(): Reads and processes the entire CSV file, including parsing data rows and calculating state statistics.
 * - ParseLine(): Parses a single data row of the CSV file into a Row object, updating it with data from the input line.
 * - CheckMaxima(): Checks and updates a map (StateMaximums) with maximum and minimum values for latitude and longitude based on the input Row.
 * - CompareExtremes(): Compares and updates the maximum and minimum values for latitude and longitude in a state.
 * - GetStateMaximums(): Retrieves a copy of the StateMaximums map, which contains state statistics.
 * - close(): Closes the CSV file if it's currently open.
 *
 * Assumptions:
 * - The input CSV file is properly formatted with valid data.
 * - The CSV file has a header row that defines column names.
 * - Latitude and longitude values are provided in decimal format.
 * - The CSV file contains data for multiple states.
 * - The CSV file follows the format: Zip,Name,State,County,Latitude,Longitude.
 * - Rows with missing or invalid data will be skipped.
 * - The CSV file may be large, so memory usage is considered.
 * - State statistics, including maximum and minimum values, are calculated and stored for each state in the data.
 */

/**
 *
 */
#include "CSVReader.h"
#include <iostream>
#include <string>
#include <sstream>

/**
 * @brief Constructor that opens the CSV file specified by the 'filename' parameter.
 * @param filename The name of the CSV file to open.
 * @pre None.
 * @post The CSVReader object is constructed, and the CSV file is opened for reading.
 */
CSVReader::CSVReader(const std::string filename) {
    ZipCSV.open(filename, std::ios::in);
}

/**
 * @brief Checks if the CSV file is open.
 * @return true if the CSV file is open, false otherwise.
 * @pre None.
 * @post None.
 */
bool CSVReader::isOpen() const {
    return ZipCSV.is_open();
}

/**
 * @brief Parses and stores the header row of the CSV file.
 * @param line The header row of the CSV file.
 * @pre The CSV file is open for reading.
 * @post The 'Headers' vector is populated with column headers from the CSV file.
 */
void CSVReader::GetHeaders(std::string &line) {
    std::stringstream stream(line);
    std::string header;
    // Parses the first of the csv by comma to get headers
    while (std::getline(stream, header, ',')) {
        // Adds headers to the vector
        Headers.push_back(header);
    }
}

/**
 * @brief Reads and processes the entire CSV file.
 * @pre The CSV file is open for reading.
 * @post The CSV file is read, and data is parsed and stored in memory.
 */
void CSVReader::ReadFile() {
    std::string line;

    // Read and store the header row of the CSV file.
    std::getline(ZipCSV, line, '\n');
    GetHeaders(line);

    // Read and process each data row of the CSV file.
    while (std::getline(ZipCSV, line, '\n')) {
        Row NewRow;
        ParseLine(line, NewRow);
        CheckMaxima(NewRow);
    }
}

/**
 * @brief Parses a single data row of the CSV file into a Row object.
 * @param Line The data row to parse.
 * @param r Reference to the Row object to store the parsed data.
 * @pre The CSV file is open for reading.
 * @post The 'r' object is updated with data from the input 'Line'.
 */
void CSVReader::ParseLine(const std::string& Line, Row& r) {
    std::stringstream stream(Line);
    std::string item;
    int fieldIndex = 0;

    while (std::getline(stream, item, ',')) {
        switch (fieldIndex) {
            case 0: // Zip
                try {
                    r.zip = std::stoi(item);
                } catch (const std::invalid_argument&) {
                    // Not an integer
                }break;
            case 1: // Name
                r.name = item;
                break;
            case 2: // State
                r.state = item;
                break;
            case 3: // County
                r.county = item;
                break;
            case 4: // Latitude
                try {
                    r.latitude = std::stof(item);
                } catch (const std::invalid_argument&) {
                    // Not a float
                }break;
            case 5: // Longitude
                try {
                    r.longitude = std::stof(item);
                } catch (const std::invalid_argument&) {
                    // Not a float
                }break;
            default:
                break;
        }
        fieldIndex++;
    }
}

/**
 * @brief Checks and updates StateMaximums map with maximum and minimum values.
 * @param R Reference to the Row object to check and update the StateMaximums map.
 * @pre The CSV file is open for reading.
 * @post The StateMaximums map is updated with extremity values from the input 'R'.
 */
void CSVReader::CheckMaxima(Row &R) {
    // If the state is already in the map
    if (!(StateMaximums.find(R.state) == StateMaximums.end())) {
        CompareExtremes(R, StateMaximums[R.state]);
    }
        // If the state is not in the map, create a new State and initialize it with the input Row.
    else {
        State newState;
        newState.StateID = R.state;
        newState.NorthMost = R;
        newState.SouthMost = R;
        newState.EastMost = R;
        newState.WestMost = R;

        // Insert the new State into the map.
        StateMaximums[R.state] = newState;
    }
}

/**
 * @brief Compares and updates the maximum and minimum values for latitude and longitude
 *        in a State. States with identical lat or long default to Zip for final comparison
 * @param Row Reference to the Row object to compare with the State's extremities.
 * @param state Reference to the State object containing the extremities to be updated.
 * @pre The CSV file is open for reading.
 * @post The State object 'state' is updated with extremity values from the input 'Row'.
 */
void CSVReader::CompareExtremes(const Row &Row, State &state) {

    // Compare latitude for northmost and southmost
    if (Row.latitude > state.NorthMost.latitude) {
        state.NorthMost = Row;
        // If latitude is the same the row with the largest zip is used
    }else if (Row.latitude == state.NorthMost.latitude) {
        if (Row.zip > state.NorthMost.zip) {
            state.NorthMost = Row;
        }
    }

    if (Row.latitude < state.SouthMost.latitude) {
        state.SouthMost = Row;
        // If latitude is the same the row with the smallest zip is used
    }else if (Row.latitude == state.SouthMost.latitude) {
        if (Row.zip < state.SouthMost.zip) {
            state.SouthMost = Row;
        }
    }

    // Compare longitude for eastmost and westmost
    if (Row.longitude > state.EastMost.longitude) {
        state.EastMost = Row;
        // If longitude is the same the row with the largest zip is used
    }else if (Row.longitude == state.EastMost.longitude) {
        if (Row.zip > state.EastMost.zip) {
            state.EastMost = Row;
        }
    }

    if (Row.longitude < state.WestMost.longitude) {
        state.WestMost = Row;
        // If longitude is the same the row with the smallest zip is used
    }else if (Row.longitude == state.WestMost.longitude) {
        if (Row.zip < state.WestMost.zip) {
            state.WestMost = Row;
        }
    }
}

/**
 * @brief Retrieves the StateMaximums map.
 * @return A copy of the StateMaximums map.
 * @pre None.
 * @post None.
 */
std::map<std::string, State> CSVReader::GetStateMaximums() {
    return StateMaximums;
}

/**
 * @brief Closes the CSV file if it's open.
 * @pre None.
 * @post The CSV file is closed if it was open.
 */
void CSVReader::close() {
    if (ZipCSV.is_open()) {
        ZipCSV.close();
    }
}
