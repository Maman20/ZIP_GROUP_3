/**
 * @file main.cpp
 * @callergraph
 * @callgraph
 * @author Chakong Lor
 * @author (Comments by Roshan) (Testing done by Shishir and Abdi) (Doxygen documentation by Abdi)
 * @brief This program reads a CSV file containing postal code data, calculates state statistics,
 * and displays the easternmost, westernmost, northernmost, and southernmost locations for each state.
 * @see CCSVReader.h and CCSVReader.cpp for Class declaration, implementation, and Assumptions.
 * @details The program utilizes the CSVReader class to process the CSV file. The methods are run twice on two
 * different csv's. One contains the rows ordered by zip code, smallest to largest, The other csv is ordered by
 * location name alphabetically A-Z. The two running's are compared to ensure that their output is the same.
 */

#include <iostream>
#include <map>
#include <string>
#include <iomanip>
#include "CSVReader.h"

// Declaration for analyzeCSV
void analyzeCSV(CSVReader &file);

// Declaration for AreStateMaximumsEqual
bool AreStateMaximumsEqual(const std::map<std::string, State>& map1, const std::map<std::string, State>& map2);

/**
 * @brief Main function to process and display state statistics from a CSV file.
 * @details This function creates a CSVReader object, opens a CSV file, reads and
 * processes the data, and displays state statistics.
 * @return 0 on success, 1 on failure (e.g., if the CSV file cannot be opened).
 */
int main() {
    // Create a CSVReader object and open a CSV file
    std::string file = "us_postal_codes.csv";
    std::cout << "Processing us_postal_codes.csv. \n" << std::endl;
    CSVReader csvReader(file);
    analyzeCSV(csvReader);

    std::string file2 = "us_postal_codes_place.csv";
    std::cout << "Processing us_postal_codes_place.csv. \n" << std::endl;
    CSVReader csvReader2(file2);
    analyzeCSV(csvReader2);

    std::cout << "\n" << std::endl;

    if (AreStateMaximumsEqual(csvReader.GetStateMaximums(), csvReader2.GetStateMaximums())) {
        std::cout << "StateMaximums maps are the same." << std::endl;
    } else {
        std::cout << "StateMaximums maps are different." << std::endl;
    }

    return 0;
}

/**
 * @brief Analyzes and displays state statistics from a CSVReader object.
 * @param csvReader The CSVReader object to analyze.
 * @pre The CSVReader object is open and initialized.
 * @post State statistics are displayed for the given CSVReader object.
 */
void analyzeCSV(CSVReader &csvReader) {
    //CSVReader csvReader(fileName);
    if (!csvReader.isOpen()) {
        std::cerr << "Failed to open CSV file." << std::endl;
        return;
    }
    // Read and process the CSV file.
    csvReader.ReadFile();

    // Print the header
    std::cout << "State       |  Eastmost        |  Westmost        |  Northmost       |  Southmost " << std::endl;
    csvReader.GetStateMaximums();
    // Iterate through the StateMaximums map and print statistics for each state
    for (const auto& pair : csvReader.GetStateMaximums() ) {
        const State& state = pair.second;
        std::cout << std::left << std::setw(10) << pair.first << "  |  "
                  << std::setw(14) << state.EastMost.zip << "  |  "
                  << std::setw(14) << state.WestMost.zip << "  |  "
                  << std::setw(14) << state.NorthMost.zip << "  |  "
                  << std::setw(14) << state.SouthMost.zip << std::endl;
    }

    // Close the CSV file.
    csvReader.close();
}

/**
 * @brief Compares two StateMaximums maps to check if they are equal.
 * @param map1 The first StateMaximums map.
 * @param map2 The second StateMaximums map.
 * @return True if the maps are equal, false otherwise.
 */
bool AreStateMaximumsEqual(const std::map<std::string, State>& map1, const std::map<std::string, State>& map2) {
    if (map1.size() != map2.size()) {
        return false; // Maps have different sizes, so they can't be the same.
    }

    for (const auto& pair : map1) {
        const std::string& stateID = pair.first;
        const State& state1 = pair.second;

        // Check if the stateID exists in map2.
        auto it = map2.find(stateID);
        if (it == map2.end()) {
            return false; // StateID not found in map2.
        }

        const State& state2 = it->second;

        // Compare the state data.
        if (state1.StateID != state2.StateID ||
            state1.NorthMost.zip != state2.NorthMost.zip ||
            state1.SouthMost.zip != state2.SouthMost.zip ||
            state1.EastMost.zip != state2.EastMost.zip ||
            state1.WestMost.zip != state2.WestMost.zip) {
            return false; // State data is different.
        }
    }

    return true; // Maps are the same.
}
