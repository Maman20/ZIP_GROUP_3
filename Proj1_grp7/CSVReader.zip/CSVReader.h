/**
 * @file CSVReader.h
 * @callergraph
 * @callgraph
 * @author Fabian MullerDahlberg
 * @author (Comments by Roshan) (Testing done by Shishir) (Doxygen documentation by Abdi)
 * @brief Declarations for class CSVReader
 * @see CSVReader.cpp for the implementation of these functions.
 * @details
 * This file declares the class CSVReader, which provides functionality to read and process CSV files.
 * The class includes member functions for opening, reading, and analyzing CSV files, as well as storing and retrieving state statistics.
 *
 * Assumptions:
 * - The input CSV file is properly formatted with valid data.
 * - The CSV file has a header row that defines column names.
 * - Latitude and longitude values are provided in decimal format.
 * - The CSV file contains data for multiple states.
 * - The CSV file follows the format: Zip,Name,State,County,Latitude,Longitude.
 * - Rows with missing or invalid data will be skipped.
 * - The CSV file may be large, so memory usage is considered.
 * - State statistics, including maximum and minimum values, are calculated and stored for each state in the data.
 */

#ifndef ZIPCODES_CSVREADER_H
#define ZIPCODES_CSVREADER_H


#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <map>

/**
 * @brief Represents a row of data in the CSV file.
 * This struct stores information for a single row of data in the CSV file,
 * including the ZIP code, name, state, county, latitude, and longitude.
 */
struct Row {
    int zip;            /**< The ZIP code. */
    std::string name;   /**< The place name. */
    std::string state;  /**< The state. */
    std::string county; /**< The county. */
    float latitude;    /**< The latitude. */
    float longitude;   /**< The longitude. */
};

 /**
  * @brief Represents state-related data.
  * This struct stores information related to a state, including the state ID,
  * and the extreme values for latitude and longitude (NorthMost, SouthMost,
  * EastMost, and WestMost rows) within that state.
  */
struct State {
    std::string StateID; /**< The state ID. */
    Row NorthMost;       /**< The row with the northernmost latitude. */
    Row SouthMost;       /**< The row with the southernmost latitude. */
    Row EastMost;        /**< The row with the easternmost longitude. */
    Row WestMost;        /**< The row with the westernmost longitude. */
};

class CSVReader {
public:

    /**
     * @brief Constructor that opens the CSV file specified by the 'filename' parameter.
     * @param filename The name of the CSV file to open.
     * @pre None.
     * @post The CSVReader object is constructed, and the CSV file is opened for reading.
     */
    CSVReader(const std::string filename);

    /**
     * @brief Checks if the CSV file is open.
     * @return true if the CSV file is open, false otherwise.
     * @pre None.
     * @post None.
     */
    bool isOpen() const;

    /**
     * @brief Parses and stores the header row of the CSV file.
     * @param line The header row of the CSV file.
     * @pre The CSV file is open for reading.
     * @post The 'Headers' vector is populated with column headers from the CSV file.
     */
    void GetHeaders(std::string &line);

    /**
     * @brief Reads and processes the entire CSV file.
     * @pre The CSV file is open for reading.
     * @post The CSV file is read, and data is parsed and stored in memory.
     */
    void ReadFile();

    /**
     * @brief Parses a single data row of the CSV file into a Row object.
     * @param Line The data row to parse.
     * @param r Reference to the Row object to store the parsed data.
     * @pre The CSV file is open for reading.
     * @post The 'r' object is updated with data from the input 'Line'.
     */
    void ParseLine(const std::string &line, Row& r);

    /**
     * @brief Checks and updates StateMaximums map with maximum and minimum values.
     * @param R Reference to the Row object to check and update the StateMaximums map.
     * @pre The CSV file is open for reading.
     * @post The StateMaximums map is updated with extremity values from the input 'R'.
     */
    void CheckMaxima(Row &R);

    /**
     * @brief Compares and updates the maximum and minimum values for latitude and longitude
     *        in a State.
     * @param Row Reference to the Row object to compare with the State's extremities.
     * @param state Reference to the State object containing the extremities to be updated.
     * @pre The CSV file is open for reading.
     * @post The State object 'state' is updated with extremity values from the input 'Row'.
     */
    void CompareExtremes(const Row &Row, State& state);

    /**
     * @brief Retrieves the StateMaximums map.
     * @return A copy of the StateMaximums map.
     * @pre None.
     * @post None.
     */
    std::map<std::string, State> GetStateMaximums();

    /**
     * @brief Closes the CSV file if it's open.
     * @pre None.
     * @post The CSV file is closed if it was open.
     */
    void close();

private:
    std::ifstream ZipCSV; /**< Represents the input CSV file stream used to open and read the CSV file. */
    std::vector<std::string> Headers; /**< Stores the column headers from the CSV file. */
    std::map<std::string, State> StateMaximums; /**< Stores state ID, as well as the maximum locations. */
};

#endif //ZIPCODES_CSVREADER_H
